﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NLCApp.Controllers
{
    public class EmployeeController : Controller
    {
        private string connectionstring = ConfigurationManager.ConnectionStrings["con"].ToString();
        // GET: Employee
        public ActionResult Index()
        {
            IEnumerable<Models.Employee> data = Get_details();
            return View(data);
        }

        [HttpPost]
        public ActionResult Add_Employee(Models.Employee E)
        {
            try
            {

                using (SqlConnection con = new SqlConnection(connectionstring))
                {

                    string response = string.Empty;
                    con.Open();
                    SqlCommand cmd = new SqlCommand("[Insertempdetails]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@QueryType", SqlDbType.VarChar, 150).Value = "insert";
                    cmd.Parameters.Add("@Name", SqlDbType.VarChar, 150).Value = E.Name;
                    cmd.Parameters.Add("@Salary", SqlDbType.VarChar, 150).Value = E.Salary;
                    cmd.Parameters.Add("@DOJ", SqlDbType.DateTime, 150).Value = E.DOJ;
                    cmd.Parameters.Add("@Gen", SqlDbType.VarChar, 150).Value = E.Gender;
                    cmd.Parameters.Add("@deptid", SqlDbType.VarChar, 150).Value = E.Dept_id;
                    SqlParameter SQLReturn = new SqlParameter("@SQLReturn", SqlDbType.NVarChar, 50);
                    SQLReturn.Direction = ParameterDirection.Output;
                    cmd.Parameters.Add(SQLReturn);
                    cmd.ExecuteNonQuery();
                    response = SQLReturn.Value.ToString().Trim();
                    var msg = "Details Added Successfully";
                    TempData["message"] = response;
                    TempData["message1"] = msg;

                }

                return RedirectToAction("Index", "Employee");

            }
            catch (Exception ex)
            {
                return RedirectToAction("Index", "Employee");

            }

        }

        private IEnumerable<Models.Employee> Get_details()
        {
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                con.Open();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("[Get_empdetails]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@QueryType", SqlDbType.VarChar, 50).Value = "get_emptdetails";
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    yield return new Models.Employee
                    {
                        Name = Convert.ToString(row["empname"]),
                        Salary = Convert.ToInt32(row["SALARY"]),
                        Gender = Convert.ToString(row["Gender"]),
                        DeptName = Convert.ToString(row["DEPT_Name"]),
                        DOJ = Convert.ToDateTime(row["DOJ"]),

                    };
                }
            }
        }


    }
}