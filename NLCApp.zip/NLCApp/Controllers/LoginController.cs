﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NLCApp.Controllers
{
    public class LoginController : Controller
    {
        private string connectionstring = ConfigurationManager.ConnectionStrings["con"].ToString();

        // GET: Login
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Check_login(Models.User Lo)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionstring))
                {
                    string response = string.Empty;
                    con.Open();
                    DataSet ds = new DataSet();
                    SqlCommand cmd = new SqlCommand("[Get_empdetails]", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@QueryType", SqlDbType.VarChar, 50).Value = "check_login";
                    cmd.Parameters.Add("@userid", SqlDbType.NVarChar, 50).Value = Lo.U_name;
                    cmd.Parameters.Add("@Password", SqlDbType.NVarChar, 50).Value = Lo.Pass_word;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    if (ds.Tables[0].Rows.Count != 0)
                    {
                        
                        Session["Role_id"] = ds.Tables[0].Rows[0]["ROLEID"].ToString(); // get role id value depend user role
              
                        TempData["message"] = "Login Successfull...!";
                        return RedirectToAction("index", "Employee");

                    }
                    else
                    {
                        TempData["message"] = "Invalid Login Details...!";
                        return RedirectToAction("Index", "Login");

                    }


                }
            }
            catch (Exception ex)
            {
                TempData["message"] = "Invalid Login Details...!";
                return RedirectToAction("index", "Login");
            }

            
        }


        [HttpPost]
        public ActionResult Get_Details()
        {
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                con.Open();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("[Get_empdetails]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@QueryType", SqlDbType.VarChar, 50).Value = "Get_details";
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                var result = new List<Models.User>();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    result.Add(item: new Models.User
                    {
                        U_name = Convert.ToString(row["UNAME"]),
                        Pass_word = Convert.ToString(row["PASSWD"]),
                        Role_id = Convert.ToInt32(row["ROLEID"])

                    });
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }



        [HttpPost]
        public ActionResult Get_dept_Details()
        {
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                con.Open();
                DataSet ds = new DataSet();
                SqlCommand cmd = new SqlCommand("[Get_empdetails]", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@QueryType", SqlDbType.VarChar, 50).Value = "get_deptdetails";
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                var result = new List<Models.Department>();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    result.Add(item: new Models.Department
                    {
                        Dept_id = Convert.ToInt32(row["DEPTID"]),
                        Dept_name = Convert.ToString(row["DEPTNAME"])
                        

                    });
                }
                return Json(result, JsonRequestBehavior.AllowGet);
            }
        }


    }
}