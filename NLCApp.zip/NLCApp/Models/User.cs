﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NLCApp.Models
{
    public class User
    {
        public int User_id { get; set; }
        public string U_name { get; set; }
        public string Pass_word { get; set; }
        public int Role_id { get; set; }
    }
}