﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NLCApp.Models
{

    public class Employee
    {
        public int Emp_id { get; set; }
        public string QueryType { get; set; }
        public string Name { get; set; }
        public int  Dept_id { get; set; }
        public int Salary { get; set; }
        public string Gender { get; set; }
        public DateTime DOJ { get; set; }

        public string DeptName { get; set; }

    }

    

    
}