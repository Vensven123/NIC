﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NLCApp.Models
{
    public class Department
    {
        public int Dept_id { get; set; }
        public string Dept_name { get; set; }
    }
}